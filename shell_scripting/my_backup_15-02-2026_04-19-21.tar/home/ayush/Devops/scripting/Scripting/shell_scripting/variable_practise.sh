#!/bin/bash

student="Sarah"

echo "Hello ${student}"
